"""
Flow Control: If Else ElIf
"""


hour = 21

if hour < 15:
    print("Good morning!")
elif hour < 20:
    print("Good afternoon!")
else:
    print("Good Night!")





