# Random
import random
types_of_drinks = ['Soda', 'Coffee', 'Water', 'Tea']
print(random.choice(types_of_drinks))

print(random.randint(1, 10))


import math
square_root = math.sqrt(64)
print(square_root)