# Going to print hello world!
# print("Hello World")
print("Hi Eric")

# This is going over
# Multiple
# Lines

"""
This is going over
multiple 
lines
"""

'''
This is going over
multiple 
lines
'''